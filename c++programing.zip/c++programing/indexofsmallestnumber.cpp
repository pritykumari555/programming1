#include <iostream>
using namespace std;
int main() {
    
    int n;
    cout << "Enter the number of elements in the array: ";
    cin >> n;

    int arr[n];
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int minIndex = 0;  // Assume the first element is the smallest

    for (int i = 1; i < n; i++) {
        if (arr[i] < arr[minIndex]) {
            minIndex = i;  // Update index of smallest element
        }
    }

    cout << "The smallest element is " << arr[minIndex] << " at index " << minIndex << endl;

    return 0;
}
