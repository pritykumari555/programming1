#include<iostream>
using namespace std;

int unique(int arr[],int sz){
    int ans=0;
    for(int i=0;i<sz;i++){
        ans=ans^arr[i];
        cout<<"index = "<<i<<" and elemnt is  : "<<arr[i]<<endl;

    }
    return ans;
}


int main(){
    int arr[]={1,2,3,4,3};
    int sz=4;
    cout<<"unique value= "<<unique(arr,sz);
   
    return 0;

}