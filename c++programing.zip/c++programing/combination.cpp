#include <iostream>
using namespace std;


// Function to calculate factorial of a number
long long factorial(int n) {
    long long result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

// Function to calculate combination C(n, r)
long long combination(int n, int r) {
    if (r > n) return 0;
    long long numerator = factorial(n);
    long long denominator = factorial(r) * factorial(n - r);
    return numerator / denominator;
}

int main() {
    int n, r;
    cout << "Enter value of n: ";
    cin >> n;
    cout << "Enter value of r: ";
    cin >> r;

    cout << "C(" << n << ", " << r << ") = " << combination(n, r) << endl;

    return 0;
}
