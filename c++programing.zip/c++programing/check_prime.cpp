#include <iostream>
using namespace std;

// Function to check if a number is prime
int prime(int n){
     int count=0;
    for(int i=2;i<=n;i++){
        if(n%i==0){
            count++;
        }
        if(count==2){
            cout<<"prime number";

        }
    else{
        cout<<"not a prime number";
    }
}
int main(){
    int num;
    cout<<"enter a number";
    cin>>num;
    cout<<prime(num);
    return 0;
} 