#include <iostream>  // This allows input-output (cin, cout) operations.
using namespace std;  // This lets us avoid writing std:: before every cout or cin.

void numberprint(int n) {
    for (int row = 0; row < 3; row++) {  // Outer loop to print 3 rows (0 to 2).
        // Print spaces at the beginning of each row
        
        // Print numbers from 1 to n
        for (int i = 1; i <= n; i++) {  // Inner loop to print numbers from 1 to n (1 to 4).
            cout << "*" << " ";  // Print the number followed by a space.
        }
        cout << endl;  // Move to the next line after printing each row.
    }
}

int main() {
    int n = 4;  // n is the number of columns (numbers) we want to print.
    numberprint(n);  // Function call to numberprint with n = 4.
    return 0;  // End of the program.
}
