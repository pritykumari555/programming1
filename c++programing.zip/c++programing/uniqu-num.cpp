#include <iostream>
using namespace std;

int main() {
    int arr[] = {4, 5, 4, 6, 7, 5, 8}; // Example array
    int n = sizeof(arr) / sizeof(arr[0]);

    for(int i = 0; i < n; i++) {
        bool isUnique = true;

        // Check if the number has appeared before
        for(int j = 0; j < i; j++) {
            if(arr[i] == arr[j]) {
                isUnique = false;
                break;
            }
        }

        // Check if the number appears later in the array
        for(int j = i + 1; j < n; j++) {
            if(arr[i] == arr[j]) {
                isUnique = false;
                break;
            }
        }

        // If the number is unique, print it
        if(isUnique) {
            cout << arr[i] << " ";
        }
    }

    return 0;
}
