#include <iostream>
using namespace std;

void number(int n){
  int num=1;
   for(int i=1;i<=n;i++){
    for(int j=1;j<=n;j++){
      cout<<num<<" ";
            num++;
        }
       cout<<endl;
    }
}
  void alphabet(int n){
    char ch='A';
    for(int i=0;i<=n;i++){
        for(int j=0;j<=n;j++){
          cout<<ch<<" ";
          ch++;
        }
        cout<<endl;
    }
  }
  void triangle(int n){
    for(int i=0;i<=n;i++){
        for(int j=1;j<i+1;j++){
            cout<<j<<" ";

        }
        cout<<endl;
    }
  }

  void repating(int n){
    for(int i=0;i<=n;i++){
      for(int j=0;j<i+1;j++){
        cout<<i+1<<" ";
      }
      cout<<endl;
    }
  }
int main(){
    int n;
    cout<<"enter a number of row:";
    cin>>n;
    number(n);
    alphabet(n);
    triangle(n);
    repating(n);
    return 0;

}