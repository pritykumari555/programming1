#include <iostream>

using namespace std;


void prime(int n){
    for(int i=2;i<=n;i++){
        if(n%i==0){
            cout<<i<<"not a prime"<<endl;
        }
        else{
            cout<<" prime"<<endl;
        }
    }
    cout<<endl;

}

int main() {
    int n;
    
   
   for(int n=1;n<10;n++){

   }
    prime();
    return 0;

}
    