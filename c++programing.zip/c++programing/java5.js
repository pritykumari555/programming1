//setInterval(function(){
   // console.log("pritysingh",Date.now());
//},2000);
//or
//const saydate=(str)=>{
    //console.log(str,Date.//now//());
//}
//const interval=setInterval(//saydate,2000,"hii");
//clearInterval(interval)//for stop all the events timeout
 const randomcolor=()=>{
    const hex="0123456789ABCDEF";
    let color="#"
    for(let i=0;i<6;i++){
     color+=hex[Math.floor(Math.random()*16)];
    }
    return color;
 }; 
 let intervalid
 const startchangecolor=function(){ 
      intervalid=setInterval(changebgcolor,1000);
    function changebgcolor(){
    document.body.style.backgroundColor=randomcolor();
    }
   };
 const stopchangecolor=function(){
   clearInterval(intervalid);
 };
 document.querySelector("#start").addEventListener('click',startchangecolor)

 document.querySelector("#stop").addEventListener('click',stopchangecolor)

