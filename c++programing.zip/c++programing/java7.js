const sum = async (a, b) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(a + b);
        }, 1000);  // Simulating a delay of 1 second
    });
  };
  
  (async () => {
    const result = await sum(5, 10);
    console.log(`Sum: ${result}`);  // Output: Sum: 15
  })();
  const subs = async (a, b) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(a - b);
        }, 6000);  // Simulating a delay of 1 second
    });
  };
  
  (async () => {
    const result = await subs(10, 5);
    console.log(`Subtraction: ${result}`);  // Output: Subtraction: 5
  })();
  const multiply = async (a, b) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(a * b);
        }, 7000);  // Simulating a delay of 1 second
    });
  };
  
  (async () => {
    const result = await multiply(5, 10);
    console.log(`Multiplication: ${result}`);  // Output: Multiplication: 50
  })();

  