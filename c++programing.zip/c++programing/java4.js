let marks=[85,97,44,76,60]
let sum=0;
for(let mark of marks ){
   // console.log(mark);
    sum=sum+mark;}
    console.log(sum);
let avg=sum/marks.length;
console.log(`averge marks of students=${avg}`);

let item=[250,645,300,900,50]
for(let price of item){
    console.log(`old price of 5 item =${price}`);
    //item++;
   let final= price*10/100;
   console.log(final);
   const am=price-final;
   console.log(`so the new price after discount of price is=${am}`);
   
}

let food=["roti","chawal","daal"];
//food.push("sbjii","dahi");
//food.pop("daal");
//console.log(`so the new food item=${food}`);
//console.log(food.toString());
food.forEach((val)=>{
    console.log(val);
});


const link = document.querySelector("#myLink");
console.log(link);
//const hrefValue = link.getAttribute("href");
//console.log(hrefValue);  // Outputs: "https://www.example.com"
