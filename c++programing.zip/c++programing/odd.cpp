#include <iostream>

using namespace std;

int main() {
    
    
    int n, sum = 0;

    // Asking for input
    cout << "Enter a positive integer: ";
    cin >> n;

    // Calculating the sum from 1 to n
    for (int i = 1; i <= n; ++i) {
        sum += i;
    }

    // Displaying the sum
    cout << "Sum of numbers from 1 to " << n << " is " << sum << endl;

    return 0;
}