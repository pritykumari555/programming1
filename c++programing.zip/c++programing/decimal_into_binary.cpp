#include<iostream>
using namespace std;

 void decimal(int n){
    int ans=0;
    int pow=1;
    while(n>0){
        int remn=n%2;
        ans=ans+remn*pow;
        n=n/2;
        pow*=10;
        

    }
    
    cout<<"decimal to binary of number is:"<<ans<<endl;
    
 }
int main(){
    int n;
    int x [5]={1,2,3,0,-1};
    int siz=5;
    int smallest=INT16_MAX;
    int smallest_index=0;
    for(int i=0;i<siz;i++){
        if(x[i]<smallest){
            smallest=x[i];
            smallest_index=i;
        }
    }
    cout<<"smallest="<<smallest<<endl;
    cout<<"index of smallest number:"<<smallest_index<<endl;
    cout<<"enter a number:";
    cin>>n;
    decimal(n);
    return 0;

}