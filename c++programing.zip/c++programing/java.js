const multiply=(a,b,finalresult)=>{
   
    
    return finalresult(a,b);
};
const mul=(c,d)=>{
    


    return c*d;
};
const add=(d,e)=>{
    return d+e;

};
const subs=(f,g)=>{
    return f-g;
}
//console.log(multiply(5,4,mul));
// console.log(multiply(multiply,4,add));
const mulResult = multiply(5, 4, mul);   // This will give us 5 * 4 = 20
const finalResult = multiply(mulResult, 4, add); 
 // This will give us 20 + 4 = 24
 const substraction=multiply(finalResult,6,subs);
 console.log("substraction = ",substraction);

console.log("multiply= ",mulResult);    // Output: 20
console.log("addition = ",finalResult);
  
