#include<iostream>
using namespace std;

int sum(int a,int b){
    a=a+120;
    b=b+10;
    return a+b;
}
int main(){

int a=5,b=4;
//cout<<"enter a and b number:";
//cin>>x;
//cin>>y;
cout<<sum(a,b)<<endl;
cout<<a<<endl;
cout<<b<<endl;
return 0;


} 