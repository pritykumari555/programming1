#include <iostream>
#include <vector>
using namespace std;

vector<int> majority_element(const vector<int>& nums) {
    int n = nums.size();
    vector<int> result;

    for (int val : nums) {
        int freq = 0;
        for (int ele : nums) {
            if (val == ele) {
                freq++;
            }
        }
        // Check if the element is a majority element and add it only once
        if (freq > n / 2 && find(result.begin(), result.end(), val) == result.end()) {
            result.push_back(val);
        }
    }
    
    return result;
}

int main() {
    vector<int> nums = {1, 2, 1, 3, 1, 3, 1, 1};
    vector<int> freq = majority_element(nums);

    for (int elem : freq) {
        cout << elem << " ";
    }
    
    return 0;
}
