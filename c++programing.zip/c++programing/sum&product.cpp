#include <iostream>
using namespace std;

void add(int arr[],int sz){
    int sum=0;
    for(int i=0;i<sz;i++){
        sum=sum+arr[i];
    }
}
int main(){
    int arr[]={1,2,3,4,5};
    //cout<<"enter an array number:";
    //cin>>arr;
    cout<<"sum of array= "<<add(arr[i],5)<<endl;
    return 0;


}