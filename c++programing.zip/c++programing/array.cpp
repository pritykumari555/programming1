#include<iostream>
using namespace std;
int main(){
    
    
    
    int num[]={2,3,-3,6};
    int size=4;
    int smallest=INT32_MAX;
    for(int i=0;i<size;i++){
        if(num[i]<smallest){
            smallest=num[i];
        }
    }cout<<"smallest="<<smallest<<endl;
    cout<<"index="<<num[0]<<endl;
    return 0;

}