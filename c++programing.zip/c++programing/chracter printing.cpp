#include<iostream>
using namespace std;
int main(){
    
    
    int n=4,i=0,j=0;
    for(i=1;i<=n;i++) {
        char ch='A';
        for(j=0;j<=n;j++){
            cout<<ch;
            ch=ch+1;
        }
        cout<<endl;
    }
    return 0;
}
