const multiply = (a, b, finalresult) => {
    return finalresult(a, b); // Callback
};

// Wrapping `mul` inside a promise
const mul = (c, d) => {
    return new Promise((resolve, reject) => {
        if (typeof c === 'number' && typeof d === 'number') {
            resolve(c * d);
        } else {
            reject('Invalid input: Both arguments must be numbers.');
        }
    });
};

const add = (d, e) => {
    return d + e;
};

const subs = (f, g) => {
    return f - g;
};

// Using `async` and `await`
const calculateResults = async () => {
    try {
        const mulResult = await mul(5, 4); // Waiting for the multiplication result
        console.log("multiply = ", mulResult); // Output: 20

        const finalResult = multiply(mulResult, 4, add); 
        console.log("addition = ", finalResult); // Output: 24

        const substraction = multiply(finalResult, 6, subs);
        console.log("substraction = ", substraction); // Output: 18
    } catch (error) {
        console.log(error);
    }
};

// Call the async function
calculateResults();
