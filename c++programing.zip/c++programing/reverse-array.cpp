#include<iostream>
using namespace std;

int sum(int arr[],int sz){
    int res=0;

    for(int i=0;i<sz;i++){
        res+=arr[i];
        
    }
    return res;
}
int main(){
    int arr[]={1,2,3,3};
    int sz=4;
    
    cout<<"totall sum of array= "<<sum(arr,sz);
    return 0;

}
    