#include <iostream>
using namespace std;


int main(){
    
    
    for(int i=1;i<=8;i++){
        //cout<<i<<endl;
        char ch='A';
        for(int j='A';j<=8;j++){
            cout<<ch<<" ";
            ch=ch+1;

        }
    
    cout<<endl;
    }
    return 0;
}