#include <iostream>

using namespace std;

int main(){
    
    
    
    
    int n=4;
    cout<<"enter a number:";
    //cin>>n;
    for(int i=1;i<=n;i++){
        //cout<<i<<endl;
        for(int j=1;j<=n;j++){
            cout<<j<<" ";

        }

    
    cout<<endl;
    }


return 0;
}