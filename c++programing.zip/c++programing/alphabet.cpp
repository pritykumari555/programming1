#include<iostream>
using namespace std;

void alphabetpattern(int n){
    for(int i=0;i<=n;i++){
        char ch='A';
        for(int j=0;j<=n;j++){
            cout<<ch<<" ";
            ch++;

        }
    
    cout<<endl;
    
    }
}
int main(){
     int n;
     cout<<"enter a number of n line:";
     cin>>n;
     alphabetpattern(n);
     return 0;

}