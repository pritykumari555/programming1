#include <iostream>
#include <vector>
#include <climits>
using namespace std;



int maxSubarraySum(vector<int>& nums) {
    int maxSum = INT_MIN;  // Initialize maxSum to the smallest integer value
    
    // Outer loop to choose the start of the subarray
    for (int i = 0; i < nums.size(); i++) {
        int currentSum = 0;  // Initialize currentSum for each new start point
        
        // Inner loop to choose the end of the subarray
        for (int j = i; j < nums.size(); j++) {
            currentSum += nums[j];  // Add current element to currentSum
            maxSum = max(maxSum, currentSum);  // Update maxSum if currentSum is greater
        }
    }
    
    return maxSum;
}

int main() {
    vector<int> nums = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    cout << "Maximum Subarray Sum: " << maxSubarraySum(nums) << endl;
    return 0;
}
