#include <iostream>
using namespace std;

void sum(int n){
    int sum=0;
    for(int i=0;i<=n;i++){
        sum=sum+i;
    }
    return sum; 
    
}


int main(){
    cout<<sum(5)<<endl;
     return 0;
}