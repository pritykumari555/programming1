#include <iostream>
using namespace std;
 int reverse_integer(int n){
    int ans=0;
    while(n>0){
        int rem=n%10;
        ans=ans*10+rem;
        n=n/10;

    }
    return ans;
 }

int main(){
    int n;
    cout<<"enter a number:";
    cin>>n;
    cout<<"reverse= "<<reverse_integer(n);
    return 0;

}