#include<iostream>
using namespace std;
int main(){
    
    int arr[4]={1,2,3,-1};
    int size=4;
    int smallest=arr[0];
    int smallestindex=0;
    for(int i=0;i<size;i++){
        if(arr[i]<smallest){
            smallest=arr[i];
            smallestindex=i;
        }
    }
    cout<<"smalesstnumber= "<<smallest<<endl;
    cout<<"smallestindex= "<<smallestindex;
    return 0;
}