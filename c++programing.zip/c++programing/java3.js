// Function that returns a Promise which resolves the multiplication after 2 seconds
const asyncMultiply = (a, b) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(a * b);
        }, 2000); // Simulate 2 seconds delay
    });
};

// Function that returns a Promise which resolves the addition after 1 second
const asyncAdd = (a, b) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(a + b);
        }, 5000); // Simulate 1 second delay
    });
};

// Async function to perform the multiplication, addition, and print the results
const calculateMultiplicationAndAddition = async () => {
    try {
        const multiplicationResult = await asyncMultiply(5, 7); // Wait for the multiplication
        console.log(`Result of 5 * 7 = ${multiplicationResult}`);
        
        const additionResult = await asyncAdd(multiplicationResult, 10); // Wait for the addition
        console.log(`Result of ${multiplicationResult} + 10 = ${additionResult}`);
    } catch (error) {
        console.error("Error:", error);
    }
};

// Call the async function to execute
calculateMultiplicationAndAddition();
