#include<iostream>
using namespace std;
void sum(int a){
    int sum=0;
    while(a>0){
    int last_digit=a%10;
     sum=sum+last_digit;
     a=a/10;
    }
     cout<<" the sum of digit:"<<sum<<endl;
}
void binomial(int a,int r){
    int fact=1;
    for(int i=1;i<=a;i++){
        fact=fact*i;
        int fact_n=fact;
    }
    for(int i=1;i<=r;i++){
        fact=fact*i;
        int fact_r=fact;
    
    }
    int combination=int fact_n/int fact_r* fact(n-r);
    cout<<"combination is ="<<combination<<endl;
}
  


int main(){
    int a,r;
    cout<<"enter a number:";
    cin>>a;
    cin>>r;
    sum(a);
    binomial(a,r);
    return 0;

}
    