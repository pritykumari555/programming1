#include<iostream>
using namespace std;

  int dec_to_binary(int decnum){
    int ans=0,pow=1;
    while(decnum>0){
        int rem=decnum%2;
        decnum=decnum/2;
        ans=ans+(rem*pow);
        pow=pow*10;


    }
    return ans;
  }

int main(){
    cout<<"binary number is="<<dec_to_binary(10)<<endl;
    
}