#include <iostream>

using namespace std;

void odd(int n){
    for(int i=0;i<=n;i++){
    if(i%2!=0){

        cout<<i<<" = odd number"<<endl;;
    
    }
    else{
        if(i%2==0){
            cout<<i<<" = even";
        }
    }
    cout<<endl;
}
}

    bool isPrime(int num) {
    if (num <= 1) return false;  // 1 and numbers less than 1 are not prime
    for (int i = 2; i < num; i++) {
        if (num % i == 0) return false;  // Not prime if divisible by any number other than 1 and itself
    }
    return true;
}

void printPrimeNumbers() {
    for (int i = 1; i <= 20; i++) {
        if (isPrime(i)) {
            cout << i << " ";
        }
    }
}

int main() {
    int n;
    cout<<"enter a number::";
    cin>>n;
    
    odd(n);
    printPrimeNumbers();

    return 0;

}