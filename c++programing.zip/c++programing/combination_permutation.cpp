#include <iostream>
using namespace std;

// Function to calculate factorial of a number
int factorial(int num) {
    int fact = 1;
    for (int i = 1; i <= num; i++) {
        fact *= i;
    }
    return fact;
}

// Function to calculate combinations C(n, r)
int combination(int n, int r) {
    return factorial(n) / (factorial(r) * factorial(n - r));
}

// Function to calculate permutations P(n, r)
int permutation(int n, int r) {
    return factorial(n) / factorial(n - r);
}

int main() {
    int n, r;
    cout << "Enter value for n: ";
    cin >> n;
    cout << "Enter value for r: ";
    cin >> r;

    cout << "Combination C(" << n << ", " << r << ") = " << combination(n, r) << endl;
    cout << "Permutation P(" << n << ", " << r << ") = " << permutation(n, r) << endl;

    return 0;
}
