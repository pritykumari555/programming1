#include<iostream>
using namespace std;
int main(){
    int a=8,b=9;
    int sum=a+b;
    cout<<"sum is:"<<sum;
    return 0;

} 